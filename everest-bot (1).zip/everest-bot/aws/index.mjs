// AWS Lambda (Node 20, Function URL, auth type NONE - protected by x-token).
//   GET /refresh     -> starts the Fargate task that collects the Everest data (returns 202)
//   GET /reputation  -> returns the latest result from S3 (409 while a collection is still running)
//
// Environment variables:
//   APP_TOKEN        long random string (same one SFMC sends in the x-token header)
//   BUCKET           S3 bucket the task uploads to (everest/latest.json)
//   CLUSTER          ECS cluster name
//   TASK_FAMILY      ECS task definition family name (e.g. everest-bot) - latest revision is used
//   SUBNETS          comma separated subnet ids (need internet access)
//   SECURITY_GROUPS  comma separated security group ids (outbound allowed)
//
// IAM for this Lambda: ecs:RunTask, ecs:ListTasks, iam:PassRole (task + execution role),
//                      s3:GetObject on arn:aws:s3:::BUCKET/everest/*
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { ECSClient, RunTaskCommand, ListTasksCommand } from "@aws-sdk/client-ecs";

const s3 = new S3Client({});
const ecs = new ECSClient({});
const { APP_TOKEN, BUCKET, CLUSTER, TASK_FAMILY, SUBNETS, SECURITY_GROUPS } = process.env;

const json = (statusCode, obj) => ({
  statusCode,
  headers: { "content-type": "application/json" },
  body: JSON.stringify(obj),
});

async function isRunning() {
  const r = await ecs.send(new ListTasksCommand({ cluster: CLUSTER, family: TASK_FAMILY, desiredStatus: "RUNNING" }));
  return (r.taskArns || []).length > 0;
}

export const handler = async (event) => {
  const headers = event.headers || {}; // Function URL lower-cases header names
  if (!APP_TOKEN || headers["x-token"] !== APP_TOKEN) return json(401, { error: "unauthorized" });
  const path = event.rawPath || "/";

  if (path.endsWith("/refresh")) {
    if (await isRunning()) return json(202, { status: "already running" });
    await ecs.send(
      new RunTaskCommand({
        cluster: CLUSTER,
        taskDefinition: TASK_FAMILY,
        launchType: "FARGATE",
        count: 1,
        networkConfiguration: {
          awsvpcConfiguration: {
            subnets: SUBNETS.split(","),
            securityGroups: SECURITY_GROUPS.split(","),
            assignPublicIp: "ENABLED", // needs a public subnet; use a NAT + DISABLED if you prefer private
          },
        },
      })
    );
    return json(202, { status: "started" });
  }

  if (path.endsWith("/reputation")) {
    if (await isRunning()) return json(409, { status: "still running" });
    try {
      const o = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: "everest/latest.json" }));
      const data = JSON.parse(await o.Body.transformToString());
      const ageMinutes = Math.round((Date.now() - Date.parse(data.generatedAt)) / 60000);
      return json(200, { meta: { ageMinutes }, ...data });
    } catch (e) {
      return json(404, { error: "no data yet" });
    }
  }

  return json(404, { error: "not found" });
};
