<script runat="server">
Platform.Load("Core", "1.1.5");

var ENDPOINT = "https://YOUR-FUNCTION-URL.lambda-url.YOUR-REGION.on.aws/refresh";
var TOKEN = "YOUR_APP_TOKEN";

var req = new Script.Util.HttpRequest(ENDPOINT);
req.emptyContentHandling = 0;
req.retries = 1;
req.continueOnError = true;
req.method = "GET";
req.setHeader("x-token", TOKEN);
var resp = req.send();

if (resp.statusCode != 202) {
  throw "Could not start the Everest collection. HTTP " + resp.statusCode + " " + String(resp.content);
}
</script>
