SFMC SETUP
==========
Data Extensions (no primary key, not sendable - each run appends rows). The "external key" must match the names used in step2-load.ssjs.

Everest_Summary
  RunDate (Date), GeneratedAt (Text 40), Blocklisted (Number), BlocklistedDateRange (Text 50),
  TrapTotal (Number, nullable), TrapSubjectCount (Number)

Everest_SenderScore
  RunDate (Date), IP (Text 50), Score (Number, nullable), ScoreDate (Text 20, nullable)

Everest_Complaints
  RunDate (Date), IP (Text 50), DateRange (Text 50), Subject (Text 500), FromAddress (Text 254), Total (Number)

Everest_TrapSubjects
  RunDate (Date), Subject (Text 500)

Automation (Automation Studio), scheduled for Wednesday:
  1. Script Activity  -> step1-trigger.ssjs   (starts the collection on AWS, returns right away)
  2. Wait Activity    -> 15 minutes           (adjust after you see how long a run takes)
  3. Script Activity  -> step2-load.ssjs      (reads the result and writes the 4 Data Extensions)
Turn on error notifications for the automation.
