<script runat="server">
Platform.Load("Core", "1.1.5");

var ENDPOINT = "https://YOUR-FUNCTION-URL.lambda-url.YOUR-REGION.on.aws/reputation";
var TOKEN = "YOUR_APP_TOKEN";
var MAX_AGE_MINUTES = 180; // fail if the data is older than this (the collection probably failed)

// Data Extension external keys (create them first - see README)
var DE_SUMMARY = "Everest_Summary";
var DE_SCORES = "Everest_SenderScore";
var DE_COMPLAINTS = "Everest_Complaints";
var DE_TRAPS = "Everest_TrapSubjects";

var req = new Script.Util.HttpRequest(ENDPOINT);
req.emptyContentHandling = 0;
req.retries = 2;
req.continueOnError = true;
req.method = "GET";
req.setHeader("x-token", TOKEN);
var resp = req.send();

if (resp.statusCode != 200) {
  throw "Everest endpoint returned HTTP " + resp.statusCode + ": " + String(resp.content);
}

var d = Platform.Function.ParseJSON(String(resp.content));

if (d.meta.ageMinutes > MAX_AGE_MINUTES) {
  throw "Everest data is " + d.meta.ageMinutes + " minutes old - today's collection probably failed";
}

var runDate = Platform.Function.Now();
var i, j, rows;

// 1) Summary (one row per run)
var traps = d.last30DaysSpamTrapsSubjectLine;
DataExtension.Init(DE_SUMMARY).Rows.Add({
  RunDate: runDate,
  GeneratedAt: d.generatedAt,
  Blocklisted: d.blocklistedValue,
  BlocklistedDateRange: d.blocklistedDateFilter.dateRange,
  TrapTotal: traps.total,
  TrapSubjectCount: traps.count
});

// 2) Sender Score per IP
var scoresDE = DataExtension.Init(DE_SCORES);
for (i = 0; i < d.senderScores.length; i++) {
  var s = d.senderScores[i];
  scoresDE.Rows.Add({ RunDate: runDate, IP: s.ip, Score: s.score, ScoreDate: s.scoreDate });
}

// 3) Complaints per IP
var complaintsDE = DataExtension.Init(DE_COMPLAINTS);
for (i = 0; i < d.complaintsByIp.length; i++) {
  var c = d.complaintsByIp[i];
  if (c.error) { throw "Complaints failed for " + c.ip + ": " + c.error; }
  for (j = 0; j < c.complaints.length; j++) {
    var r = c.complaints[j];
    complaintsDE.Rows.Add({
      RunDate: runDate, IP: c.ip, DateRange: c.dateRange,
      Subject: r.subject, FromAddress: r.fromAddress, Total: r.total
    });
  }
}

// 4) Pristine spam trap subject lines (last 30 days)
var trapsDE = DataExtension.Init(DE_TRAPS);
for (i = 0; i < traps.subjectLines.length; i++) {
  trapsDE.Rows.Add({ RunDate: runDate, Subject: traps.subjectLines[i] });
}
</script>
