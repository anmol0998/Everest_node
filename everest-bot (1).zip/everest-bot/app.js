// app.js - the web service SFMC calls.
//   GET /reputation   (header x-token)  -> returns the LAST collected result instantly
//   GET /refresh      (header x-token)  -> starts a new collection in the background (202)
//   GET /health                         -> "ok"
// The slow browser work (login, filters, 2 IP pages) runs in the background on a schedule
// (REFRESH_HOURS, default 6) and on startup, so SFMC never waits for it.
require("dotenv").config();
const express = require("express");
const fs = require("fs");
const { getEverestData } = require("./Server");

const REFRESH_MS = (Number(process.env.REFRESH_HOURS) || 6) * 60 * 60 * 1000;
const FILE = "everest-last.json";

let latest = null; // { fetchedAt, data }
let running = null; // in-flight refresh
let lastError = null;

try {
  latest = JSON.parse(fs.readFileSync(FILE, "utf8")); // survive restarts when the disk is kept
} catch {}

function refresh() {
  if (running) return running;
  console.log("Refresh started");
  running = getEverestData()
    .then((data) => {
      latest = { fetchedAt: new Date().toISOString(), data };
      lastError = null;
      try {
        fs.writeFileSync(FILE, JSON.stringify(latest));
      } catch {}
      console.log("Refresh done");
    })
    .catch((e) => {
      lastError = { at: new Date().toISOString(), message: e.message };
      console.error("Refresh failed:", e.message);
    })
    .finally(() => {
      running = null;
    });
  return running;
}

const app = express();
const auth = (req, res, next) =>
  process.env.APP_TOKEN && req.get("x-token") === process.env.APP_TOKEN
    ? next()
    : res.status(401).json({ error: "unauthorized" });

app.get("/health", (req, res) => res.send("ok"));

app.get("/reputation", auth, (req, res) => {
  const meta = { refreshing: !!running, lastError };
  if (!latest) return res.status(503).json({ status: "no data yet", ...meta });
  const ageMinutes = Math.round((Date.now() - new Date(latest.fetchedAt).getTime()) / 60000);
  res.json({
    meta: { fetchedAt: latest.fetchedAt, ageMinutes, stale: ageMinutes * 60000 > 2 * REFRESH_MS, ...meta },
    ...latest.data,
  });
});

app.get("/refresh", auth, (req, res) => {
  refresh();
  res.status(202).json({ status: "refresh started" });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Listening on port ${port}`);
  refresh(); // first collection on startup
  setInterval(refresh, REFRESH_MS);
});
