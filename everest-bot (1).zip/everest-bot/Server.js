// Server.js
// Flow (all in DTC BU):
//   1. Log in (saved session reused) and switch to DTC BU
//   2. Monitoring > Reputation: date filter -> "Last 7 Days" -> Apply, read Blocklisted
//   3. Traps URL in a NEW TAB (last 30 days) -> subject lines -> last30DaysSpamTrapsSubjectLine
//   4. For EACH IP: open its Sender Score report page in a new tab, date filter -> Last 7 Days -> Apply,
//      scroll to Complaints, set Show = 50, read every row of the complaints table
//   5. Sender Score for your IPs comes from the Everest API (X-API-KEY)
//
// .env: EV_USER, EV_PASS, EV_API_KEY, SENDER_IPS (comma separated), APP_TOKEN (app.js only)
// Optional: HEADLESS=0 (watch the browser), IGNORE_TLS=1 (company proxy cert errors),
//           BROWSER_CHANNEL=chromium (servers/Docker)
//           S3_BUCKET + AWS_REGION (upload the result to S3 after a run)

require("dotenv").config(); // must load BEFORE the settings below are read
const { chromium, request } = require("playwright");
const fs = require("fs");

const CFG = {
  loginUrl: "https://everest.validity.com/login",
  userSel: "#email",
  passSel: "#password",
  submitSel: "#standardsignin",
  afterLoginUrl: "**/dashboards/**",

  buSelect: "#switchaccount",
  buValue: "1025648", // DTC BU 515008882
  buLabel: "DTC BU 515008882",

  dateInput: "#dashboard-date", // date range box (Reputation overview and Sender Score report)
  dateOption: "Last 7 Days",

  // traps URL: part between "includes=" and "&startdate" (still encoded)
  trapIncludes:
    "%7B%22type%22%3A%22trap%22%2C%22age%22%3A%22%3E%203%20years%22%2C%22trapType%22%3A%5B%22pristine%22%5D%7D",
  trapsBase: "https://everest.validity.com/reputation/iframedata/traps",
  pageSize: 50, // first 50 rows only
  trapDays: 30, // today - 29 days
  subjectCol: 3, // 4th value in each tabledata row

  // page the "View Report" button loads for one IP (the Sender Score side panel)
  senderScoreIframe: "https://everest.validity.com/reputation/senderscore/iframe",
  complaintsShow: "50",

  senderScoreBase: "https://api.everest.validity.com/api/2.0/reputation/senderscore",
};

const STATE_FILE = "everest-session.json";
const TLS = process.env.IGNORE_TLS === "1";

// ---------- helpers ----------
const pad = (n) => String(n).padStart(2, "0");
const fmt = (d, time) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${time}`;

// window of the last N days including today (7 -> today-6 ... today)
function lastNDays(n) {
  const end = new Date();
  const start = new Date();
  start.setDate(start.getDate() - (n - 1));
  return { startdate: fmt(start, "00:00:00"), enddate: fmt(end, "23:59:00") };
}

function trapsUrl(win, start) {
  return (
    `${CFG.trapsBase}?includes=${CFG.trapIncludes}` +
    `&startdate=${encodeURIComponent(win.startdate)}` +
    `&enddate=${encodeURIComponent(win.enddate)}` +
    `&start=${start}&length=${CFG.pageSize}`
  );
}

// Turn \u00ae -> ®, \/ -> /, &reg; -> ®, etc. into normal readable text
function cleanText(t) {
  if (typeof t !== "string") return "";
  return t
    .replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/\\\//g, "/")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&reg;/gi, "®")
    .replace(/&trade;/gi, "™")
    .replace(/&nbsp;/gi, " ")
    .replace(/&quot;/gi, '"')
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&amp;/gi, "&")
    .replace(/\s+/g, " ")
    .trim();
}

// ---------- Sender Score (API key) ----------
// Everest returns: { results: { sender_score: [ {day:"2026-09-23", value:99}, ... ] } }
function parseSenderScore(body) {
  const arr = body?.results?.sender_score;
  if (Array.isArray(arr) && arr.length) {
    const latest = [...arr].sort((a, b) => String(a.day).localeCompare(String(b.day))).pop();
    return { score: latest.value ?? null, scoreDate: latest.day ?? null };
  }
  return { score: body?.score ?? body?.data?.score ?? null, scoreDate: null };
}

async function getSenderScores(ips) {
  const api = await request.newContext({
    extraHTTPHeaders: { "X-API-KEY": process.env.EV_API_KEY, Accept: "application/json" },
    ignoreHTTPSErrors: TLS,
  });
  const out = [];
  for (const ip of ips) {
    try {
      const r = await api.get(`${CFG.senderScoreBase}/${ip}`);
      const body = await r.json();
      out.push({ ip, ...parseSenderScore(body), httpStatus: r.status() });
    } catch (e) {
      out.push({ ip, score: null, scoreDate: null, error: e.message });
    }
  }
  await api.dispose();
  return out;
}

// ---------- Browser: login + switch to DTC BU ----------
async function loginAndSwitch(browser) {
  const context = await browser.newContext({
    ignoreHTTPSErrors: TLS,
    ...(fs.existsSync(STATE_FILE) ? { storageState: STATE_FILE } : {}),
  });
  const page = await context.newPage();

  await page.goto(CFG.loginUrl, { waitUntil: "networkidle" });
  if (await page.locator(CFG.passSel).count()) {
    await page.fill(CFG.userSel, process.env.EV_USER);
    await page.fill(CFG.passSel, process.env.EV_PASS);
    await page.click(CFG.submitSel);
    await page.waitForURL(CFG.afterLoginUrl);
    await page.waitForLoadState("networkidle");
    await context.storageState({ path: STATE_FILE });
  }

  await page.waitForSelector(CFG.buSelect, { state: "attached", timeout: 30000 });
  const current = await page.locator(CFG.buSelect).inputValue();
  console.log("Account before:", current);
  if (current !== CFG.buValue) {
    await Promise.all([
      page.waitForNavigation({ waitUntil: "load", timeout: 30000 }),
      page.selectOption(CFG.buSelect, CFG.buValue).catch(() => {}), // reload interrupts the call
    ]);
    await page.waitForLoadState("networkidle");
  }
  const chosen = await page.locator(`${CFG.buSelect} option:checked`).innerText();
  console.log("Account now:", chosen.trim());
  if (!chosen.includes("515008882")) throw new Error(`Not on DTC BU, on: ${chosen.trim()}`);

  return { context, page };
}

// ---------- Date filter: open calendar -> Last 7 Days -> Apply ----------
async function applyLast7Days(page) {
  const dateBox = page.locator(CFG.dateInput);
  await dateBox.waitFor({ state: "visible", timeout: 30000 });
  await dateBox.click();

  const option = page
    .locator("li:visible")
    .filter({ hasText: new RegExp("^\\s*" + CFG.dateOption + "\\s*$") })
    .or(page.getByText(CFG.dateOption, { exact: true }))
    .first();
  await option.click();
  await page.waitForLoadState("networkidle").catch(() => {});
  await page.waitForTimeout(1000);

  // Some pickers apply as soon as a range is clicked, so don't fail if there is no Apply button
  const apply = page
    .locator('.applyBtn:visible, input[value="Apply"]:visible')
    .or(page.getByRole("button", { name: "Apply", exact: true }))
    .or(page.getByText("Apply", { exact: true }))
    .first();
  const hasApply = await apply.waitFor({ state: "visible", timeout: 4000 }).then(() => true).catch(() => false);
  if (hasApply) {
    await Promise.all([
      page.waitForNavigation({ waitUntil: "load", timeout: 15000 }).catch(() => {}),
      apply.click(),
    ]);
  } else {
    console.log("No Apply button shown - the range click already applied the filter");
  }
  await page.waitForLoadState("networkidle").catch(() => {});
  await page.waitForTimeout(1500); // let the page refresh

  const dateRange = (await page.locator(CFG.dateInput).inputValue()).trim();
  const f = (d) => `${pad(d.getMonth() + 1)}/${pad(d.getDate())}/${d.getFullYear()}`;
  const today = new Date();
  const from = new Date();
  from.setDate(from.getDate() - 6);
  if (dateRange !== `${f(from)} - ${f(today)}`)
    console.warn(`Warning: date box shows "${dateRange}", expected "${f(from)} - ${f(today)}" for ${CFG.dateOption}`);
  return dateRange;
}

// ---------- Reputation overview: filter -> read Blocklisted ----------
async function getBlocklisted(page) {
  const rep = page.getByRole("link", { name: "Reputation", exact: true }).first();
  if (!(await rep.isVisible())) await page.getByText("Monitoring", { exact: true }).first().click();
  await rep.click();
  await page.waitForLoadState("networkidle");

  const dateRange = await applyLast7Days(page);
  await page.screenshot({ path: "reputation-filtered.png" }).catch(() => {});

  // Blocklisted card: <div>Blocklisted <button/></div><div class="text-large">0</div>
  const byXpath = page.locator(
    "xpath=//div[normalize-space(.)='Blocklisted']/following-sibling::div[contains(@class,'text-large')][1]"
  );
  const byCss = page.locator("div.ms-3").filter({ hasText: "Blocklisted" }).locator(".text-large").first();
  let raw;
  try {
    raw = (await byXpath.first().innerText({ timeout: 10000 })).trim();
  } catch {
    raw = (await byCss.innerText({ timeout: 10000 })).trim();
  }
  const num = Number(raw.replace(/[^\d.-]/g, ""));
  const value = raw !== "" && !Number.isNaN(num) ? num : raw;
  console.log(`Date range now: ${dateRange} | Blocklisted: ${value}`);
  return { value, dateRange };
}

// ---------- Traps URL in a different tab ----------
async function getTrapsInNewTab(context, win) {
  const tab = await context.newPage();
  try {
    const resp = await tab.goto(trapsUrl(win, 0), { waitUntil: "domcontentloaded", timeout: 60000 });
    const raw = resp ? await resp.text() : await tab.innerText("body");
    let body;
    try {
      body = JSON.parse(raw);
    } catch {
      try {
        body = JSON.parse(await tab.innerText("body"));
      } catch {
        throw new Error(
          `Traps tab did not return JSON (HTTP ${resp?.status()}). ` +
            `If the session expired, delete everest-session.json and retry. Start: ${raw.slice(0, 200)}`
        );
      }
    }
    fs.writeFileSync("traps-raw.json", JSON.stringify(body, null, 2));
    return body;
  } finally {
    await tab.close().catch(() => {});
  }
}

// ---------- Complaints for one IP ----------
// Opens the same page "View Report > (IP)" shows, in its own tab, then:
// date filter -> Last 7 Days -> Apply, scroll to Complaints, Show = 50, read the table
async function getComplaintsForIp(context, ip, win7, score) {
  const tab = await context.newPage();
  try {
    const url =
      `${CFG.senderScoreIframe}/${ip}?startdate=${encodeURIComponent(win7.startdate)}` +
      `&enddate=${encodeURIComponent(win7.enddate)}` +
      (score != null ? `&cached_score=${score}` : "");
    await tab.goto(url, { waitUntil: "load", timeout: 60000 });
    await tab.waitForLoadState("networkidle").catch(() => {});

    // calendar -> Last 7 Days (the URL already carries the same 7 days, so a hiccup here is not fatal)
    let dateRange = null;
    try {
      dateRange = await applyLast7Days(tab);
    } catch (e) {
      console.warn(`[${ip}] date picker step skipped: ${e.message.split("\n")[0]}`);
      dateRange = await tab.locator(CFG.dateInput).inputValue().catch(() => null);
    }

    // bottom of page: Complaints > Show 50
    const lengthSel = tab.locator('select[name="complaint_table_length"]');
    await lengthSel.scrollIntoViewIfNeeded({ timeout: 30000 });
    await lengthSel.selectOption(CFG.complaintsShow).catch(() => lengthSel.selectOption({ label: CFG.complaintsShow }));
    await tab.waitForLoadState("networkidle").catch(() => {});
    await tab.waitForTimeout(1500);

    const readRows = () =>
      tab.$$eval("#complaint_table tbody tr", (trs) =>
        trs
          .map((tr) => [...tr.querySelectorAll("td")].map((td) => td.innerText.trim()))
          .filter((c) => c.length >= 3) // the "No data available" row has a single cell
      );

    const rows = [];
    for (let page = 0; page < 20; page++) {
      rows.push(...(await readRows()));
      const nextLi = tab.locator("#complaint_table_next");
      const cls = (await nextLi.getAttribute("class").catch(() => "")) || "";
      if (!(await nextLi.count()) || cls.includes("disabled")) break;
      const link = tab.locator("#complaint_table_next a");
      await ((await link.count()) ? link.first() : nextLi).click();
      await tab.waitForTimeout(700);
    }

    const info = await tab.locator("#complaint_table_info").innerText().catch(() => "");
    const complaints = rows.map((c) => ({
      subject: cleanText(c[0]),
      fromAddress: c[1],
      total: Number(c[2].replace(/[^\d.-]/g, "")) || 0,
    }));
    const complaintTotal = complaints.reduce((sum, c) => sum + c.total, 0);
    console.log(`[${ip}] ${dateRange} | complaint rows: ${complaints.length} | ${info.trim()}`);
    return { ip, dateRange, entriesInfo: info.trim(), rowCount: complaints.length, complaintTotal, complaints };
  } catch (e) {
    await tab.screenshot({ path: `error-complaints-${ip}.png`, fullPage: true }).catch(() => {});
    console.error(`[${ip}] complaints failed: ${e.message.split("\n")[0]}`);
    return { ip, error: e.message.split("\n")[0], complaints: [] };
  } finally {
    await tab.close().catch(() => {});
  }
}

// ---------- Build the final object ----------
async function getEverestData() {
  const ips = (process.env.SENDER_IPS || "").split(",").map((s) => s.trim()).filter(Boolean);
  if (!ips.length) throw new Error("Set SENDER_IPS in .env, e.g. SENDER_IPS=1.2.3.4,5.6.7.8");
  if (!process.env.EV_API_KEY) throw new Error("Set EV_API_KEY in .env");

  const win30 = lastNDays(CFG.trapDays);
  const win7 = lastNDays(7);
  const senderScores = await getSenderScores(ips);

  // BROWSER_CHANNEL: "chrome" (default, your installed Chrome) or "chromium" (Playwright's own browser, used on servers)
  const channel = process.env.BROWSER_CHANNEL || "chrome";
  const browser = await chromium.launch({
    ...(channel === "chromium" ? {} : { channel }),
    headless: process.env.HEADLESS !== "0",
  });
  let body, blocklist;
  const complaintsByIp = [];
  try {
    const { context, page } = await loginAndSwitch(browser);
    try {
      blocklist = await getBlocklisted(page);
      body = await getTrapsInNewTab(context, win30);
    } catch (e) {
      await page.screenshot({ path: "error.png", fullPage: true }).catch(() => {});
      throw e;
    }
    for (const ip of ips) {
      const score = senderScores.find((s) => s.ip === ip)?.score ?? null;
      complaintsByIp.push(await getComplaintsForIp(context, ip, win7, score));
    }
  } finally {
    await browser.close();
  }

  const rows = Array.isArray(body.tabledata) ? body.tabledata : [];
  const subjectLines = rows
    .map((r) => cleanText(Array.isArray(r) ? r[CFG.subjectCol] : ""))
    .filter(Boolean);
  console.log(`tabledata rows: ${rows.length} | subject lines: ${subjectLines.length}`);

  return {
    generatedAt: new Date().toISOString(),
    businessUnit: CFG.buLabel,
    blocklistedValue: blocklist.value,
    blocklistedDateFilter: { option: CFG.dateOption, dateRange: blocklist.dateRange },
    senderScores: senderScores.map(({ ip, score, scoreDate, httpStatus, error }) => ({
      ip,
      score,
      scoreDate,
      httpStatus,
      error,
    })),
    complaintsByIp,
    last30DaysSpamTrapsSubjectLine: {
      startDate: win30.startdate,
      endDate: win30.enddate,
      total: body.recordsTotal ?? body.recordsFiltered ?? body.total ?? null,
      count: subjectLines.length,
      subjectLines,
    },
  };
}

module.exports = { getEverestData, getReputation: getEverestData };

// Optional: upload the result to S3 (used when this runs as a weekly job on AWS)
async function uploadToS3(data) {
  const bucket = process.env.S3_BUCKET;
  if (!bucket) return;
  const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
  const s3 = new S3Client({ region: process.env.AWS_REGION });
  const body = JSON.stringify(data);
  const day = new Date().toISOString().slice(0, 10);
  for (const Key of ["everest/latest.json", `everest/history/${day}.json`]) {
    await s3.send(new PutObjectCommand({ Bucket: bucket, Key, Body: body, ContentType: "application/json" }));
  }
  console.log(`Uploaded to s3://${bucket}/everest/latest.json`);
}

// Run directly: node Server.js  (or npm run debug). Runs once, saves the result, then exits.
if (require.main === module) {
  getEverestData()
    .then(async (d) => {
      fs.writeFileSync("everest-data.json", JSON.stringify(d, null, 2));
      console.log(JSON.stringify(d, null, 2));
      await uploadToS3(d);
    })
    .catch((e) => {
      console.error("Failed:", e.message);
      process.exit(1); // non-zero exit = the scheduled task shows as failed
    });
}
